CS 4402 Distributed & Parallel Systems
Assignment 2
Sarah Whelan 250778849

To run:
1) Type "make" to create the executables q1 and q2
2) Run ./q1 and follow the prompt
3) Run ./q2 and follow the prompts
